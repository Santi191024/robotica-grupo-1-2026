// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from modeloo_robot:srv/EjecutarTrayectoria.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "modeloo_robot/srv/ejecutar_trayectoria.h"


#ifndef MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__FUNCTIONS_H_
#define MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/action_type_support_struct.h"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_runtime_c/service_type_support_struct.h"
#include "rosidl_runtime_c/type_description/type_description__struct.h"
#include "rosidl_runtime_c/type_description/type_source__struct.h"
#include "rosidl_runtime_c/type_hash.h"
#include "rosidl_runtime_c/visibility_control.h"
#include "modeloo_robot/msg/rosidl_generator_c__visibility_control.h"

#include "modeloo_robot/srv/detail/ejecutar_trayectoria__struct.h"

/// Retrieve pointer to the hash of the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_type_hash_t *
modeloo_robot__srv__EjecutarTrayectoria__get_type_hash(
  const rosidl_service_type_support_t * type_support);

/// Retrieve pointer to the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeDescription *
modeloo_robot__srv__EjecutarTrayectoria__get_type_description(
  const rosidl_service_type_support_t * type_support);

/// Retrieve pointer to the single raw source text that defined this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeSource *
modeloo_robot__srv__EjecutarTrayectoria__get_individual_type_description_source(
  const rosidl_service_type_support_t * type_support);

/// Retrieve pointer to the recursive raw sources that defined the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeSource__Sequence *
modeloo_robot__srv__EjecutarTrayectoria__get_type_description_sources(
  const rosidl_service_type_support_t * type_support);

/// Initialize srv/EjecutarTrayectoria message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * modeloo_robot__srv__EjecutarTrayectoria_Request
 * )) before or use
 * modeloo_robot__srv__EjecutarTrayectoria_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Request__init(modeloo_robot__srv__EjecutarTrayectoria_Request * msg);

/// Finalize srv/EjecutarTrayectoria message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Request__fini(modeloo_robot__srv__EjecutarTrayectoria_Request * msg);

/// Create srv/EjecutarTrayectoria message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * modeloo_robot__srv__EjecutarTrayectoria_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
modeloo_robot__srv__EjecutarTrayectoria_Request *
modeloo_robot__srv__EjecutarTrayectoria_Request__create(void);

/// Destroy srv/EjecutarTrayectoria message.
/**
 * It calls
 * modeloo_robot__srv__EjecutarTrayectoria_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Request__destroy(modeloo_robot__srv__EjecutarTrayectoria_Request * msg);

/// Check for srv/EjecutarTrayectoria message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Request__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Request * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Request * rhs);

/// Copy a srv/EjecutarTrayectoria message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Request__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Request * input,
  modeloo_robot__srv__EjecutarTrayectoria_Request * output);

/// Retrieve pointer to the hash of the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_type_hash_t *
modeloo_robot__srv__EjecutarTrayectoria_Request__get_type_hash(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeDescription *
modeloo_robot__srv__EjecutarTrayectoria_Request__get_type_description(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the single raw source text that defined this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeSource *
modeloo_robot__srv__EjecutarTrayectoria_Request__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the recursive raw sources that defined the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeSource__Sequence *
modeloo_robot__srv__EjecutarTrayectoria_Request__get_type_description_sources(
  const rosidl_message_type_support_t * type_support);

/// Initialize array of srv/EjecutarTrayectoria messages.
/**
 * It allocates the memory for the number of elements and calls
 * modeloo_robot__srv__EjecutarTrayectoria_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__init(modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * array, size_t size);

/// Finalize array of srv/EjecutarTrayectoria messages.
/**
 * It calls
 * modeloo_robot__srv__EjecutarTrayectoria_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__fini(modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * array);

/// Create array of srv/EjecutarTrayectoria messages.
/**
 * It allocates the memory for the array and calls
 * modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence *
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__create(size_t size);

/// Destroy array of srv/EjecutarTrayectoria messages.
/**
 * It calls
 * modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__destroy(modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * array);

/// Check for srv/EjecutarTrayectoria message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * rhs);

/// Copy an array of srv/EjecutarTrayectoria messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * input,
  modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * output);

/// Initialize srv/EjecutarTrayectoria message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * modeloo_robot__srv__EjecutarTrayectoria_Response
 * )) before or use
 * modeloo_robot__srv__EjecutarTrayectoria_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Response__init(modeloo_robot__srv__EjecutarTrayectoria_Response * msg);

/// Finalize srv/EjecutarTrayectoria message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Response__fini(modeloo_robot__srv__EjecutarTrayectoria_Response * msg);

/// Create srv/EjecutarTrayectoria message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * modeloo_robot__srv__EjecutarTrayectoria_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
modeloo_robot__srv__EjecutarTrayectoria_Response *
modeloo_robot__srv__EjecutarTrayectoria_Response__create(void);

/// Destroy srv/EjecutarTrayectoria message.
/**
 * It calls
 * modeloo_robot__srv__EjecutarTrayectoria_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Response__destroy(modeloo_robot__srv__EjecutarTrayectoria_Response * msg);

/// Check for srv/EjecutarTrayectoria message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Response__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Response * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Response * rhs);

/// Copy a srv/EjecutarTrayectoria message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Response__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Response * input,
  modeloo_robot__srv__EjecutarTrayectoria_Response * output);

/// Retrieve pointer to the hash of the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_type_hash_t *
modeloo_robot__srv__EjecutarTrayectoria_Response__get_type_hash(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeDescription *
modeloo_robot__srv__EjecutarTrayectoria_Response__get_type_description(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the single raw source text that defined this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeSource *
modeloo_robot__srv__EjecutarTrayectoria_Response__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the recursive raw sources that defined the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeSource__Sequence *
modeloo_robot__srv__EjecutarTrayectoria_Response__get_type_description_sources(
  const rosidl_message_type_support_t * type_support);

/// Initialize array of srv/EjecutarTrayectoria messages.
/**
 * It allocates the memory for the number of elements and calls
 * modeloo_robot__srv__EjecutarTrayectoria_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__init(modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * array, size_t size);

/// Finalize array of srv/EjecutarTrayectoria messages.
/**
 * It calls
 * modeloo_robot__srv__EjecutarTrayectoria_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__fini(modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * array);

/// Create array of srv/EjecutarTrayectoria messages.
/**
 * It allocates the memory for the array and calls
 * modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence *
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__create(size_t size);

/// Destroy array of srv/EjecutarTrayectoria messages.
/**
 * It calls
 * modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__destroy(modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * array);

/// Check for srv/EjecutarTrayectoria message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * rhs);

/// Copy an array of srv/EjecutarTrayectoria messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * input,
  modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * output);

/// Initialize srv/EjecutarTrayectoria message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * modeloo_robot__srv__EjecutarTrayectoria_Event
 * )) before or use
 * modeloo_robot__srv__EjecutarTrayectoria_Event__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Event__init(modeloo_robot__srv__EjecutarTrayectoria_Event * msg);

/// Finalize srv/EjecutarTrayectoria message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Event__fini(modeloo_robot__srv__EjecutarTrayectoria_Event * msg);

/// Create srv/EjecutarTrayectoria message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * modeloo_robot__srv__EjecutarTrayectoria_Event__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
modeloo_robot__srv__EjecutarTrayectoria_Event *
modeloo_robot__srv__EjecutarTrayectoria_Event__create(void);

/// Destroy srv/EjecutarTrayectoria message.
/**
 * It calls
 * modeloo_robot__srv__EjecutarTrayectoria_Event__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Event__destroy(modeloo_robot__srv__EjecutarTrayectoria_Event * msg);

/// Check for srv/EjecutarTrayectoria message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Event__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Event * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Event * rhs);

/// Copy a srv/EjecutarTrayectoria message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Event__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Event * input,
  modeloo_robot__srv__EjecutarTrayectoria_Event * output);

/// Retrieve pointer to the hash of the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_type_hash_t *
modeloo_robot__srv__EjecutarTrayectoria_Event__get_type_hash(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeDescription *
modeloo_robot__srv__EjecutarTrayectoria_Event__get_type_description(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the single raw source text that defined this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeSource *
modeloo_robot__srv__EjecutarTrayectoria_Event__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the recursive raw sources that defined the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
const rosidl_runtime_c__type_description__TypeSource__Sequence *
modeloo_robot__srv__EjecutarTrayectoria_Event__get_type_description_sources(
  const rosidl_message_type_support_t * type_support);

/// Initialize array of srv/EjecutarTrayectoria messages.
/**
 * It allocates the memory for the number of elements and calls
 * modeloo_robot__srv__EjecutarTrayectoria_Event__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__init(modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * array, size_t size);

/// Finalize array of srv/EjecutarTrayectoria messages.
/**
 * It calls
 * modeloo_robot__srv__EjecutarTrayectoria_Event__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__fini(modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * array);

/// Create array of srv/EjecutarTrayectoria messages.
/**
 * It allocates the memory for the array and calls
 * modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence *
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__create(size_t size);

/// Destroy array of srv/EjecutarTrayectoria messages.
/**
 * It calls
 * modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
void
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__destroy(modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * array);

/// Check for srv/EjecutarTrayectoria message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * rhs);

/// Copy an array of srv/EjecutarTrayectoria messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_modeloo_robot
bool
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * input,
  modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * output);
#ifdef __cplusplus
}
#endif

#endif  // MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__FUNCTIONS_H_
