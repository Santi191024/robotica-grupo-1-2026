// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from modeloo_robot:srv/EjecutarTrayectoria.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "modeloo_robot/srv/ejecutar_trayectoria.hpp"


#ifndef MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__TRAITS_HPP_
#define MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "modeloo_robot/srv/detail/ejecutar_trayectoria__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace modeloo_robot
{

namespace srv
{

inline void to_flow_style_yaml(
  const EjecutarTrayectoria_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: ejecutar
  {
    out << "ejecutar: ";
    rosidl_generator_traits::value_to_yaml(msg.ejecutar, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EjecutarTrayectoria_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: ejecutar
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ejecutar: ";
    rosidl_generator_traits::value_to_yaml(msg.ejecutar, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EjecutarTrayectoria_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace modeloo_robot

namespace rosidl_generator_traits
{

[[deprecated("use modeloo_robot::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const modeloo_robot::srv::EjecutarTrayectoria_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  modeloo_robot::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use modeloo_robot::srv::to_yaml() instead")]]
inline std::string to_yaml(const modeloo_robot::srv::EjecutarTrayectoria_Request & msg)
{
  return modeloo_robot::srv::to_yaml(msg);
}

template<>
inline const char * data_type<modeloo_robot::srv::EjecutarTrayectoria_Request>()
{
  return "modeloo_robot::srv::EjecutarTrayectoria_Request";
}

template<>
inline const char * name<modeloo_robot::srv::EjecutarTrayectoria_Request>()
{
  return "modeloo_robot/srv/EjecutarTrayectoria_Request";
}

template<>
struct has_fixed_size<modeloo_robot::srv::EjecutarTrayectoria_Request>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<modeloo_robot::srv::EjecutarTrayectoria_Request>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<modeloo_robot::srv::EjecutarTrayectoria_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace modeloo_robot
{

namespace srv
{

inline void to_flow_style_yaml(
  const EjecutarTrayectoria_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: succes
  {
    out << "succes: ";
    rosidl_generator_traits::value_to_yaml(msg.succes, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EjecutarTrayectoria_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: succes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "succes: ";
    rosidl_generator_traits::value_to_yaml(msg.succes, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EjecutarTrayectoria_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace modeloo_robot

namespace rosidl_generator_traits
{

[[deprecated("use modeloo_robot::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const modeloo_robot::srv::EjecutarTrayectoria_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  modeloo_robot::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use modeloo_robot::srv::to_yaml() instead")]]
inline std::string to_yaml(const modeloo_robot::srv::EjecutarTrayectoria_Response & msg)
{
  return modeloo_robot::srv::to_yaml(msg);
}

template<>
inline const char * data_type<modeloo_robot::srv::EjecutarTrayectoria_Response>()
{
  return "modeloo_robot::srv::EjecutarTrayectoria_Response";
}

template<>
inline const char * name<modeloo_robot::srv::EjecutarTrayectoria_Response>()
{
  return "modeloo_robot/srv/EjecutarTrayectoria_Response";
}

template<>
struct has_fixed_size<modeloo_robot::srv::EjecutarTrayectoria_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<modeloo_robot::srv::EjecutarTrayectoria_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<modeloo_robot::srv::EjecutarTrayectoria_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__traits.hpp"

namespace modeloo_robot
{

namespace srv
{

inline void to_flow_style_yaml(
  const EjecutarTrayectoria_Event & msg,
  std::ostream & out)
{
  out << "{";
  // member: info
  {
    out << "info: ";
    to_flow_style_yaml(msg.info, out);
    out << ", ";
  }

  // member: request
  {
    if (msg.request.size() == 0) {
      out << "request: []";
    } else {
      out << "request: [";
      size_t pending_items = msg.request.size();
      for (auto item : msg.request) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: response
  {
    if (msg.response.size() == 0) {
      out << "response: []";
    } else {
      out << "response: [";
      size_t pending_items = msg.response.size();
      for (auto item : msg.response) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EjecutarTrayectoria_Event & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "info:\n";
    to_block_style_yaml(msg.info, out, indentation + 2);
  }

  // member: request
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.request.size() == 0) {
      out << "request: []\n";
    } else {
      out << "request:\n";
      for (auto item : msg.request) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: response
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.response.size() == 0) {
      out << "response: []\n";
    } else {
      out << "response:\n";
      for (auto item : msg.response) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EjecutarTrayectoria_Event & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace modeloo_robot

namespace rosidl_generator_traits
{

[[deprecated("use modeloo_robot::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const modeloo_robot::srv::EjecutarTrayectoria_Event & msg,
  std::ostream & out, size_t indentation = 0)
{
  modeloo_robot::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use modeloo_robot::srv::to_yaml() instead")]]
inline std::string to_yaml(const modeloo_robot::srv::EjecutarTrayectoria_Event & msg)
{
  return modeloo_robot::srv::to_yaml(msg);
}

template<>
inline const char * data_type<modeloo_robot::srv::EjecutarTrayectoria_Event>()
{
  return "modeloo_robot::srv::EjecutarTrayectoria_Event";
}

template<>
inline const char * name<modeloo_robot::srv::EjecutarTrayectoria_Event>()
{
  return "modeloo_robot/srv/EjecutarTrayectoria_Event";
}

template<>
struct has_fixed_size<modeloo_robot::srv::EjecutarTrayectoria_Event>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<modeloo_robot::srv::EjecutarTrayectoria_Event>
  : std::integral_constant<bool, has_bounded_size<modeloo_robot::srv::EjecutarTrayectoria_Request>::value && has_bounded_size<modeloo_robot::srv::EjecutarTrayectoria_Response>::value && has_bounded_size<service_msgs::msg::ServiceEventInfo>::value> {};

template<>
struct is_message<modeloo_robot::srv::EjecutarTrayectoria_Event>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<modeloo_robot::srv::EjecutarTrayectoria>()
{
  return "modeloo_robot::srv::EjecutarTrayectoria";
}

template<>
inline const char * name<modeloo_robot::srv::EjecutarTrayectoria>()
{
  return "modeloo_robot/srv/EjecutarTrayectoria";
}

template<>
struct has_fixed_size<modeloo_robot::srv::EjecutarTrayectoria>
  : std::integral_constant<
    bool,
    has_fixed_size<modeloo_robot::srv::EjecutarTrayectoria_Request>::value &&
    has_fixed_size<modeloo_robot::srv::EjecutarTrayectoria_Response>::value
  >
{
};

template<>
struct has_bounded_size<modeloo_robot::srv::EjecutarTrayectoria>
  : std::integral_constant<
    bool,
    has_bounded_size<modeloo_robot::srv::EjecutarTrayectoria_Request>::value &&
    has_bounded_size<modeloo_robot::srv::EjecutarTrayectoria_Response>::value
  >
{
};

template<>
struct is_service<modeloo_robot::srv::EjecutarTrayectoria>
  : std::true_type
{
};

template<>
struct is_service_request<modeloo_robot::srv::EjecutarTrayectoria_Request>
  : std::true_type
{
};

template<>
struct is_service_response<modeloo_robot::srv::EjecutarTrayectoria_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__TRAITS_HPP_
