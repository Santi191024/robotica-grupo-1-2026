// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from modeloo_robot:srv/EjecutarTrayectoria.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "modeloo_robot/srv/ejecutar_trayectoria.hpp"


#ifndef MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__STRUCT_HPP_
#define MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Request __attribute__((deprecated))
#else
# define DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Request __declspec(deprecated)
#endif

namespace modeloo_robot
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct EjecutarTrayectoria_Request_
{
  using Type = EjecutarTrayectoria_Request_<ContainerAllocator>;

  explicit EjecutarTrayectoria_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ejecutar = false;
    }
  }

  explicit EjecutarTrayectoria_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ejecutar = false;
    }
  }

  // field types and members
  using _ejecutar_type =
    bool;
  _ejecutar_type ejecutar;

  // setters for named parameter idiom
  Type & set__ejecutar(
    const bool & _arg)
  {
    this->ejecutar = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Request
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Request
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EjecutarTrayectoria_Request_ & other) const
  {
    if (this->ejecutar != other.ejecutar) {
      return false;
    }
    return true;
  }
  bool operator!=(const EjecutarTrayectoria_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EjecutarTrayectoria_Request_

// alias to use template instance with default allocator
using EjecutarTrayectoria_Request =
  modeloo_robot::srv::EjecutarTrayectoria_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace modeloo_robot


#ifndef _WIN32
# define DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Response __attribute__((deprecated))
#else
# define DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Response __declspec(deprecated)
#endif

namespace modeloo_robot
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct EjecutarTrayectoria_Response_
{
  using Type = EjecutarTrayectoria_Response_<ContainerAllocator>;

  explicit EjecutarTrayectoria_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->succes = false;
      this->message = "";
    }
  }

  explicit EjecutarTrayectoria_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->succes = false;
      this->message = "";
    }
  }

  // field types and members
  using _succes_type =
    bool;
  _succes_type succes;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;

  // setters for named parameter idiom
  Type & set__succes(
    const bool & _arg)
  {
    this->succes = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Response
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Response
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EjecutarTrayectoria_Response_ & other) const
  {
    if (this->succes != other.succes) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    return true;
  }
  bool operator!=(const EjecutarTrayectoria_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EjecutarTrayectoria_Response_

// alias to use template instance with default allocator
using EjecutarTrayectoria_Response =
  modeloo_robot::srv::EjecutarTrayectoria_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace modeloo_robot


// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Event __attribute__((deprecated))
#else
# define DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Event __declspec(deprecated)
#endif

namespace modeloo_robot
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct EjecutarTrayectoria_Event_
{
  using Type = EjecutarTrayectoria_Event_<ContainerAllocator>;

  explicit EjecutarTrayectoria_Event_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_init)
  {
    (void)_init;
  }

  explicit EjecutarTrayectoria_Event_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _info_type =
    service_msgs::msg::ServiceEventInfo_<ContainerAllocator>;
  _info_type info;
  using _request_type =
    rosidl_runtime_cpp::BoundedVector<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator>>>;
  _request_type request;
  using _response_type =
    rosidl_runtime_cpp::BoundedVector<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator>>>;
  _response_type response;

  // setters for named parameter idiom
  Type & set__info(
    const service_msgs::msg::ServiceEventInfo_<ContainerAllocator> & _arg)
  {
    this->info = _arg;
    return *this;
  }
  Type & set__request(
    const rosidl_runtime_cpp::BoundedVector<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<modeloo_robot::srv::EjecutarTrayectoria_Request_<ContainerAllocator>>> & _arg)
  {
    this->request = _arg;
    return *this;
  }
  Type & set__response(
    const rosidl_runtime_cpp::BoundedVector<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<modeloo_robot::srv::EjecutarTrayectoria_Response_<ContainerAllocator>>> & _arg)
  {
    this->response = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator> *;
  using ConstRawPtr =
    const modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Event
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__modeloo_robot__srv__EjecutarTrayectoria_Event
    std::shared_ptr<modeloo_robot::srv::EjecutarTrayectoria_Event_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EjecutarTrayectoria_Event_ & other) const
  {
    if (this->info != other.info) {
      return false;
    }
    if (this->request != other.request) {
      return false;
    }
    if (this->response != other.response) {
      return false;
    }
    return true;
  }
  bool operator!=(const EjecutarTrayectoria_Event_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EjecutarTrayectoria_Event_

// alias to use template instance with default allocator
using EjecutarTrayectoria_Event =
  modeloo_robot::srv::EjecutarTrayectoria_Event_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace modeloo_robot

namespace modeloo_robot
{

namespace srv
{

struct EjecutarTrayectoria
{
  using Request = modeloo_robot::srv::EjecutarTrayectoria_Request;
  using Response = modeloo_robot::srv::EjecutarTrayectoria_Response;
  using Event = modeloo_robot::srv::EjecutarTrayectoria_Event;
};

}  // namespace srv

}  // namespace modeloo_robot

#endif  // MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__STRUCT_HPP_
