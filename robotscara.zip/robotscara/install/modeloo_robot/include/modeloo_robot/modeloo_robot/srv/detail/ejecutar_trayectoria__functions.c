// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from modeloo_robot:srv/EjecutarTrayectoria.idl
// generated code does not contain a copyright notice
#include "modeloo_robot/srv/detail/ejecutar_trayectoria__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

bool
modeloo_robot__srv__EjecutarTrayectoria_Request__init(modeloo_robot__srv__EjecutarTrayectoria_Request * msg)
{
  if (!msg) {
    return false;
  }
  // ejecutar
  return true;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Request__fini(modeloo_robot__srv__EjecutarTrayectoria_Request * msg)
{
  if (!msg) {
    return;
  }
  // ejecutar
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Request__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Request * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // ejecutar
  if (lhs->ejecutar != rhs->ejecutar) {
    return false;
  }
  return true;
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Request__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Request * input,
  modeloo_robot__srv__EjecutarTrayectoria_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // ejecutar
  output->ejecutar = input->ejecutar;
  return true;
}

modeloo_robot__srv__EjecutarTrayectoria_Request *
modeloo_robot__srv__EjecutarTrayectoria_Request__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  modeloo_robot__srv__EjecutarTrayectoria_Request * msg = (modeloo_robot__srv__EjecutarTrayectoria_Request *)allocator.allocate(sizeof(modeloo_robot__srv__EjecutarTrayectoria_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(modeloo_robot__srv__EjecutarTrayectoria_Request));
  bool success = modeloo_robot__srv__EjecutarTrayectoria_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Request__destroy(modeloo_robot__srv__EjecutarTrayectoria_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    modeloo_robot__srv__EjecutarTrayectoria_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__init(modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  modeloo_robot__srv__EjecutarTrayectoria_Request * data = NULL;

  if (size) {
    data = (modeloo_robot__srv__EjecutarTrayectoria_Request *)allocator.zero_allocate(size, sizeof(modeloo_robot__srv__EjecutarTrayectoria_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = modeloo_robot__srv__EjecutarTrayectoria_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        modeloo_robot__srv__EjecutarTrayectoria_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__fini(modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      modeloo_robot__srv__EjecutarTrayectoria_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence *
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * array = (modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence *)allocator.allocate(sizeof(modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__destroy(modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!modeloo_robot__srv__EjecutarTrayectoria_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * input,
  modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(modeloo_robot__srv__EjecutarTrayectoria_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    modeloo_robot__srv__EjecutarTrayectoria_Request * data =
      (modeloo_robot__srv__EjecutarTrayectoria_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!modeloo_robot__srv__EjecutarTrayectoria_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          modeloo_robot__srv__EjecutarTrayectoria_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!modeloo_robot__srv__EjecutarTrayectoria_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `message`
#include "rosidl_runtime_c/string_functions.h"

bool
modeloo_robot__srv__EjecutarTrayectoria_Response__init(modeloo_robot__srv__EjecutarTrayectoria_Response * msg)
{
  if (!msg) {
    return false;
  }
  // succes
  // message
  if (!rosidl_runtime_c__String__init(&msg->message)) {
    modeloo_robot__srv__EjecutarTrayectoria_Response__fini(msg);
    return false;
  }
  return true;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Response__fini(modeloo_robot__srv__EjecutarTrayectoria_Response * msg)
{
  if (!msg) {
    return;
  }
  // succes
  // message
  rosidl_runtime_c__String__fini(&msg->message);
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Response__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Response * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // succes
  if (lhs->succes != rhs->succes) {
    return false;
  }
  // message
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->message), &(rhs->message)))
  {
    return false;
  }
  return true;
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Response__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Response * input,
  modeloo_robot__srv__EjecutarTrayectoria_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // succes
  output->succes = input->succes;
  // message
  if (!rosidl_runtime_c__String__copy(
      &(input->message), &(output->message)))
  {
    return false;
  }
  return true;
}

modeloo_robot__srv__EjecutarTrayectoria_Response *
modeloo_robot__srv__EjecutarTrayectoria_Response__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  modeloo_robot__srv__EjecutarTrayectoria_Response * msg = (modeloo_robot__srv__EjecutarTrayectoria_Response *)allocator.allocate(sizeof(modeloo_robot__srv__EjecutarTrayectoria_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(modeloo_robot__srv__EjecutarTrayectoria_Response));
  bool success = modeloo_robot__srv__EjecutarTrayectoria_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Response__destroy(modeloo_robot__srv__EjecutarTrayectoria_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    modeloo_robot__srv__EjecutarTrayectoria_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__init(modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  modeloo_robot__srv__EjecutarTrayectoria_Response * data = NULL;

  if (size) {
    data = (modeloo_robot__srv__EjecutarTrayectoria_Response *)allocator.zero_allocate(size, sizeof(modeloo_robot__srv__EjecutarTrayectoria_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = modeloo_robot__srv__EjecutarTrayectoria_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        modeloo_robot__srv__EjecutarTrayectoria_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__fini(modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      modeloo_robot__srv__EjecutarTrayectoria_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence *
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * array = (modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence *)allocator.allocate(sizeof(modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__destroy(modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!modeloo_robot__srv__EjecutarTrayectoria_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * input,
  modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(modeloo_robot__srv__EjecutarTrayectoria_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    modeloo_robot__srv__EjecutarTrayectoria_Response * data =
      (modeloo_robot__srv__EjecutarTrayectoria_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!modeloo_robot__srv__EjecutarTrayectoria_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          modeloo_robot__srv__EjecutarTrayectoria_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!modeloo_robot__srv__EjecutarTrayectoria_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `info`
#include "service_msgs/msg/detail/service_event_info__functions.h"
// Member `request`
// Member `response`
// already included above
// #include "modeloo_robot/srv/detail/ejecutar_trayectoria__functions.h"

bool
modeloo_robot__srv__EjecutarTrayectoria_Event__init(modeloo_robot__srv__EjecutarTrayectoria_Event * msg)
{
  if (!msg) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__init(&msg->info)) {
    modeloo_robot__srv__EjecutarTrayectoria_Event__fini(msg);
    return false;
  }
  // request
  if (!modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__init(&msg->request, 0)) {
    modeloo_robot__srv__EjecutarTrayectoria_Event__fini(msg);
    return false;
  }
  // response
  if (!modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__init(&msg->response, 0)) {
    modeloo_robot__srv__EjecutarTrayectoria_Event__fini(msg);
    return false;
  }
  return true;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Event__fini(modeloo_robot__srv__EjecutarTrayectoria_Event * msg)
{
  if (!msg) {
    return;
  }
  // info
  service_msgs__msg__ServiceEventInfo__fini(&msg->info);
  // request
  modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__fini(&msg->request);
  // response
  modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__fini(&msg->response);
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Event__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Event * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Event * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__are_equal(
      &(lhs->info), &(rhs->info)))
  {
    return false;
  }
  // request
  if (!modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__are_equal(
      &(lhs->request), &(rhs->request)))
  {
    return false;
  }
  // response
  if (!modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__are_equal(
      &(lhs->response), &(rhs->response)))
  {
    return false;
  }
  return true;
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Event__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Event * input,
  modeloo_robot__srv__EjecutarTrayectoria_Event * output)
{
  if (!input || !output) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__copy(
      &(input->info), &(output->info)))
  {
    return false;
  }
  // request
  if (!modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__copy(
      &(input->request), &(output->request)))
  {
    return false;
  }
  // response
  if (!modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__copy(
      &(input->response), &(output->response)))
  {
    return false;
  }
  return true;
}

modeloo_robot__srv__EjecutarTrayectoria_Event *
modeloo_robot__srv__EjecutarTrayectoria_Event__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  modeloo_robot__srv__EjecutarTrayectoria_Event * msg = (modeloo_robot__srv__EjecutarTrayectoria_Event *)allocator.allocate(sizeof(modeloo_robot__srv__EjecutarTrayectoria_Event), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(modeloo_robot__srv__EjecutarTrayectoria_Event));
  bool success = modeloo_robot__srv__EjecutarTrayectoria_Event__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Event__destroy(modeloo_robot__srv__EjecutarTrayectoria_Event * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    modeloo_robot__srv__EjecutarTrayectoria_Event__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__init(modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  modeloo_robot__srv__EjecutarTrayectoria_Event * data = NULL;

  if (size) {
    data = (modeloo_robot__srv__EjecutarTrayectoria_Event *)allocator.zero_allocate(size, sizeof(modeloo_robot__srv__EjecutarTrayectoria_Event), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = modeloo_robot__srv__EjecutarTrayectoria_Event__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        modeloo_robot__srv__EjecutarTrayectoria_Event__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__fini(modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      modeloo_robot__srv__EjecutarTrayectoria_Event__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence *
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * array = (modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence *)allocator.allocate(sizeof(modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__destroy(modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__are_equal(const modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * lhs, const modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!modeloo_robot__srv__EjecutarTrayectoria_Event__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence__copy(
  const modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * input,
  modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(modeloo_robot__srv__EjecutarTrayectoria_Event);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    modeloo_robot__srv__EjecutarTrayectoria_Event * data =
      (modeloo_robot__srv__EjecutarTrayectoria_Event *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!modeloo_robot__srv__EjecutarTrayectoria_Event__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          modeloo_robot__srv__EjecutarTrayectoria_Event__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!modeloo_robot__srv__EjecutarTrayectoria_Event__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
