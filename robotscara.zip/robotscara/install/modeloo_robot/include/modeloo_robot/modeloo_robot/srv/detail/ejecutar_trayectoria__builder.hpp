// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from modeloo_robot:srv/EjecutarTrayectoria.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "modeloo_robot/srv/ejecutar_trayectoria.hpp"


#ifndef MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__BUILDER_HPP_
#define MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "modeloo_robot/srv/detail/ejecutar_trayectoria__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace modeloo_robot
{

namespace srv
{

namespace builder
{

class Init_EjecutarTrayectoria_Request_ejecutar
{
public:
  Init_EjecutarTrayectoria_Request_ejecutar()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::modeloo_robot::srv::EjecutarTrayectoria_Request ejecutar(::modeloo_robot::srv::EjecutarTrayectoria_Request::_ejecutar_type arg)
  {
    msg_.ejecutar = std::move(arg);
    return std::move(msg_);
  }

private:
  ::modeloo_robot::srv::EjecutarTrayectoria_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::modeloo_robot::srv::EjecutarTrayectoria_Request>()
{
  return modeloo_robot::srv::builder::Init_EjecutarTrayectoria_Request_ejecutar();
}

}  // namespace modeloo_robot


namespace modeloo_robot
{

namespace srv
{

namespace builder
{

class Init_EjecutarTrayectoria_Response_message
{
public:
  explicit Init_EjecutarTrayectoria_Response_message(::modeloo_robot::srv::EjecutarTrayectoria_Response & msg)
  : msg_(msg)
  {}
  ::modeloo_robot::srv::EjecutarTrayectoria_Response message(::modeloo_robot::srv::EjecutarTrayectoria_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::modeloo_robot::srv::EjecutarTrayectoria_Response msg_;
};

class Init_EjecutarTrayectoria_Response_succes
{
public:
  Init_EjecutarTrayectoria_Response_succes()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EjecutarTrayectoria_Response_message succes(::modeloo_robot::srv::EjecutarTrayectoria_Response::_succes_type arg)
  {
    msg_.succes = std::move(arg);
    return Init_EjecutarTrayectoria_Response_message(msg_);
  }

private:
  ::modeloo_robot::srv::EjecutarTrayectoria_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::modeloo_robot::srv::EjecutarTrayectoria_Response>()
{
  return modeloo_robot::srv::builder::Init_EjecutarTrayectoria_Response_succes();
}

}  // namespace modeloo_robot


namespace modeloo_robot
{

namespace srv
{

namespace builder
{

class Init_EjecutarTrayectoria_Event_response
{
public:
  explicit Init_EjecutarTrayectoria_Event_response(::modeloo_robot::srv::EjecutarTrayectoria_Event & msg)
  : msg_(msg)
  {}
  ::modeloo_robot::srv::EjecutarTrayectoria_Event response(::modeloo_robot::srv::EjecutarTrayectoria_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::modeloo_robot::srv::EjecutarTrayectoria_Event msg_;
};

class Init_EjecutarTrayectoria_Event_request
{
public:
  explicit Init_EjecutarTrayectoria_Event_request(::modeloo_robot::srv::EjecutarTrayectoria_Event & msg)
  : msg_(msg)
  {}
  Init_EjecutarTrayectoria_Event_response request(::modeloo_robot::srv::EjecutarTrayectoria_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_EjecutarTrayectoria_Event_response(msg_);
  }

private:
  ::modeloo_robot::srv::EjecutarTrayectoria_Event msg_;
};

class Init_EjecutarTrayectoria_Event_info
{
public:
  Init_EjecutarTrayectoria_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EjecutarTrayectoria_Event_request info(::modeloo_robot::srv::EjecutarTrayectoria_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_EjecutarTrayectoria_Event_request(msg_);
  }

private:
  ::modeloo_robot::srv::EjecutarTrayectoria_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::modeloo_robot::srv::EjecutarTrayectoria_Event>()
{
  return modeloo_robot::srv::builder::Init_EjecutarTrayectoria_Event_info();
}

}  // namespace modeloo_robot

#endif  // MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__BUILDER_HPP_
