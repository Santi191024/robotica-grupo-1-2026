// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from modeloo_robot:srv/EjecutarTrayectoria.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "modeloo_robot/srv/ejecutar_trayectoria.h"


#ifndef MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__STRUCT_H_
#define MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/EjecutarTrayectoria in the package modeloo_robot.
typedef struct modeloo_robot__srv__EjecutarTrayectoria_Request
{
  bool ejecutar;
} modeloo_robot__srv__EjecutarTrayectoria_Request;

// Struct for a sequence of modeloo_robot__srv__EjecutarTrayectoria_Request.
typedef struct modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence
{
  modeloo_robot__srv__EjecutarTrayectoria_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/EjecutarTrayectoria in the package modeloo_robot.
typedef struct modeloo_robot__srv__EjecutarTrayectoria_Response
{
  bool succes;
  rosidl_runtime_c__String message;
} modeloo_robot__srv__EjecutarTrayectoria_Response;

// Struct for a sequence of modeloo_robot__srv__EjecutarTrayectoria_Response.
typedef struct modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence
{
  modeloo_robot__srv__EjecutarTrayectoria_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  modeloo_robot__srv__EjecutarTrayectoria_Event__request__MAX_SIZE = 1
};
// response
enum
{
  modeloo_robot__srv__EjecutarTrayectoria_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/EjecutarTrayectoria in the package modeloo_robot.
typedef struct modeloo_robot__srv__EjecutarTrayectoria_Event
{
  service_msgs__msg__ServiceEventInfo info;
  modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence request;
  modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence response;
} modeloo_robot__srv__EjecutarTrayectoria_Event;

// Struct for a sequence of modeloo_robot__srv__EjecutarTrayectoria_Event.
typedef struct modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence
{
  modeloo_robot__srv__EjecutarTrayectoria_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} modeloo_robot__srv__EjecutarTrayectoria_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // MODELOO_ROBOT__SRV__DETAIL__EJECUTAR_TRAYECTORIA__STRUCT_H_
