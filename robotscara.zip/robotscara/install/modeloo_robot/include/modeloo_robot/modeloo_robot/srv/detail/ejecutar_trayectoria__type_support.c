// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from modeloo_robot:srv/EjecutarTrayectoria.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "modeloo_robot/srv/detail/ejecutar_trayectoria__rosidl_typesupport_introspection_c.h"
#include "modeloo_robot/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "modeloo_robot/srv/detail/ejecutar_trayectoria__functions.h"
#include "modeloo_robot/srv/detail/ejecutar_trayectoria__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  modeloo_robot__srv__EjecutarTrayectoria_Request__init(message_memory);
}

void modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_fini_function(void * message_memory)
{
  modeloo_robot__srv__EjecutarTrayectoria_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_message_member_array[1] = {
  {
    "ejecutar",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(modeloo_robot__srv__EjecutarTrayectoria_Request, ejecutar),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_message_members = {
  "modeloo_robot__srv",  // message namespace
  "EjecutarTrayectoria_Request",  // message name
  1,  // number of fields
  sizeof(modeloo_robot__srv__EjecutarTrayectoria_Request),
  false,  // has_any_key_member_
  modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_message_member_array,  // message members
  modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_message_type_support_handle = {
  0,
  &modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_message_members,
  get_message_typesupport_handle_function,
  &modeloo_robot__srv__EjecutarTrayectoria_Request__get_type_hash,
  &modeloo_robot__srv__EjecutarTrayectoria_Request__get_type_description,
  &modeloo_robot__srv__EjecutarTrayectoria_Request__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_modeloo_robot
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria_Request)() {
  if (!modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_message_type_support_handle.typesupport_identifier) {
    modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "modeloo_robot/srv/detail/ejecutar_trayectoria__rosidl_typesupport_introspection_c.h"
// already included above
// #include "modeloo_robot/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "modeloo_robot/srv/detail/ejecutar_trayectoria__functions.h"
// already included above
// #include "modeloo_robot/srv/detail/ejecutar_trayectoria__struct.h"


// Include directives for member types
// Member `message`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  modeloo_robot__srv__EjecutarTrayectoria_Response__init(message_memory);
}

void modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_fini_function(void * message_memory)
{
  modeloo_robot__srv__EjecutarTrayectoria_Response__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_message_member_array[2] = {
  {
    "succes",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(modeloo_robot__srv__EjecutarTrayectoria_Response, succes),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "message",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(modeloo_robot__srv__EjecutarTrayectoria_Response, message),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_message_members = {
  "modeloo_robot__srv",  // message namespace
  "EjecutarTrayectoria_Response",  // message name
  2,  // number of fields
  sizeof(modeloo_robot__srv__EjecutarTrayectoria_Response),
  false,  // has_any_key_member_
  modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_message_member_array,  // message members
  modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_message_type_support_handle = {
  0,
  &modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_message_members,
  get_message_typesupport_handle_function,
  &modeloo_robot__srv__EjecutarTrayectoria_Response__get_type_hash,
  &modeloo_robot__srv__EjecutarTrayectoria_Response__get_type_description,
  &modeloo_robot__srv__EjecutarTrayectoria_Response__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_modeloo_robot
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria_Response)() {
  if (!modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_message_type_support_handle.typesupport_identifier) {
    modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "modeloo_robot/srv/detail/ejecutar_trayectoria__rosidl_typesupport_introspection_c.h"
// already included above
// #include "modeloo_robot/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "modeloo_robot/srv/detail/ejecutar_trayectoria__functions.h"
// already included above
// #include "modeloo_robot/srv/detail/ejecutar_trayectoria__struct.h"


// Include directives for member types
// Member `info`
#include "service_msgs/msg/service_event_info.h"
// Member `info`
#include "service_msgs/msg/detail/service_event_info__rosidl_typesupport_introspection_c.h"
// Member `request`
// Member `response`
#include "modeloo_robot/srv/ejecutar_trayectoria.h"
// Member `request`
// Member `response`
// already included above
// #include "modeloo_robot/srv/detail/ejecutar_trayectoria__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  modeloo_robot__srv__EjecutarTrayectoria_Event__init(message_memory);
}

void modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_fini_function(void * message_memory)
{
  modeloo_robot__srv__EjecutarTrayectoria_Event__fini(message_memory);
}

size_t modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__size_function__EjecutarTrayectoria_Event__request(
  const void * untyped_member)
{
  const modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * member =
    (const modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence *)(untyped_member);
  return member->size;
}

const void * modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_const_function__EjecutarTrayectoria_Event__request(
  const void * untyped_member, size_t index)
{
  const modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * member =
    (const modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence *)(untyped_member);
  return &member->data[index];
}

void * modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_function__EjecutarTrayectoria_Event__request(
  void * untyped_member, size_t index)
{
  modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * member =
    (modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence *)(untyped_member);
  return &member->data[index];
}

void modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__fetch_function__EjecutarTrayectoria_Event__request(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const modeloo_robot__srv__EjecutarTrayectoria_Request * item =
    ((const modeloo_robot__srv__EjecutarTrayectoria_Request *)
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_const_function__EjecutarTrayectoria_Event__request(untyped_member, index));
  modeloo_robot__srv__EjecutarTrayectoria_Request * value =
    (modeloo_robot__srv__EjecutarTrayectoria_Request *)(untyped_value);
  *value = *item;
}

void modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__assign_function__EjecutarTrayectoria_Event__request(
  void * untyped_member, size_t index, const void * untyped_value)
{
  modeloo_robot__srv__EjecutarTrayectoria_Request * item =
    ((modeloo_robot__srv__EjecutarTrayectoria_Request *)
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_function__EjecutarTrayectoria_Event__request(untyped_member, index));
  const modeloo_robot__srv__EjecutarTrayectoria_Request * value =
    (const modeloo_robot__srv__EjecutarTrayectoria_Request *)(untyped_value);
  *item = *value;
}

bool modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__resize_function__EjecutarTrayectoria_Event__request(
  void * untyped_member, size_t size)
{
  modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence * member =
    (modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence *)(untyped_member);
  modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__fini(member);
  return modeloo_robot__srv__EjecutarTrayectoria_Request__Sequence__init(member, size);
}

size_t modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__size_function__EjecutarTrayectoria_Event__response(
  const void * untyped_member)
{
  const modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * member =
    (const modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence *)(untyped_member);
  return member->size;
}

const void * modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_const_function__EjecutarTrayectoria_Event__response(
  const void * untyped_member, size_t index)
{
  const modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * member =
    (const modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence *)(untyped_member);
  return &member->data[index];
}

void * modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_function__EjecutarTrayectoria_Event__response(
  void * untyped_member, size_t index)
{
  modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * member =
    (modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence *)(untyped_member);
  return &member->data[index];
}

void modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__fetch_function__EjecutarTrayectoria_Event__response(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const modeloo_robot__srv__EjecutarTrayectoria_Response * item =
    ((const modeloo_robot__srv__EjecutarTrayectoria_Response *)
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_const_function__EjecutarTrayectoria_Event__response(untyped_member, index));
  modeloo_robot__srv__EjecutarTrayectoria_Response * value =
    (modeloo_robot__srv__EjecutarTrayectoria_Response *)(untyped_value);
  *value = *item;
}

void modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__assign_function__EjecutarTrayectoria_Event__response(
  void * untyped_member, size_t index, const void * untyped_value)
{
  modeloo_robot__srv__EjecutarTrayectoria_Response * item =
    ((modeloo_robot__srv__EjecutarTrayectoria_Response *)
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_function__EjecutarTrayectoria_Event__response(untyped_member, index));
  const modeloo_robot__srv__EjecutarTrayectoria_Response * value =
    (const modeloo_robot__srv__EjecutarTrayectoria_Response *)(untyped_value);
  *item = *value;
}

bool modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__resize_function__EjecutarTrayectoria_Event__response(
  void * untyped_member, size_t size)
{
  modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence * member =
    (modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence *)(untyped_member);
  modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__fini(member);
  return modeloo_robot__srv__EjecutarTrayectoria_Response__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_member_array[3] = {
  {
    "info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(modeloo_robot__srv__EjecutarTrayectoria_Event, info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "request",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    true,  // is array
    1,  // array size
    true,  // is upper bound
    offsetof(modeloo_robot__srv__EjecutarTrayectoria_Event, request),  // bytes offset in struct
    NULL,  // default value
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__size_function__EjecutarTrayectoria_Event__request,  // size() function pointer
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_const_function__EjecutarTrayectoria_Event__request,  // get_const(index) function pointer
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_function__EjecutarTrayectoria_Event__request,  // get(index) function pointer
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__fetch_function__EjecutarTrayectoria_Event__request,  // fetch(index, &value) function pointer
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__assign_function__EjecutarTrayectoria_Event__request,  // assign(index, value) function pointer
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__resize_function__EjecutarTrayectoria_Event__request  // resize(index) function pointer
  },
  {
    "response",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    true,  // is array
    1,  // array size
    true,  // is upper bound
    offsetof(modeloo_robot__srv__EjecutarTrayectoria_Event, response),  // bytes offset in struct
    NULL,  // default value
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__size_function__EjecutarTrayectoria_Event__response,  // size() function pointer
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_const_function__EjecutarTrayectoria_Event__response,  // get_const(index) function pointer
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__get_function__EjecutarTrayectoria_Event__response,  // get(index) function pointer
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__fetch_function__EjecutarTrayectoria_Event__response,  // fetch(index, &value) function pointer
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__assign_function__EjecutarTrayectoria_Event__response,  // assign(index, value) function pointer
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__resize_function__EjecutarTrayectoria_Event__response  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_members = {
  "modeloo_robot__srv",  // message namespace
  "EjecutarTrayectoria_Event",  // message name
  3,  // number of fields
  sizeof(modeloo_robot__srv__EjecutarTrayectoria_Event),
  false,  // has_any_key_member_
  modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_member_array,  // message members
  modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_init_function,  // function to initialize message memory (memory has to be allocated)
  modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_type_support_handle = {
  0,
  &modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_members,
  get_message_typesupport_handle_function,
  &modeloo_robot__srv__EjecutarTrayectoria_Event__get_type_hash,
  &modeloo_robot__srv__EjecutarTrayectoria_Event__get_type_description,
  &modeloo_robot__srv__EjecutarTrayectoria_Event__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_modeloo_robot
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria_Event)() {
  modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, service_msgs, msg, ServiceEventInfo)();
  modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria_Request)();
  modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria_Response)();
  if (!modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_type_support_handle.typesupport_identifier) {
    modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "modeloo_robot/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "modeloo_robot/srv/detail/ejecutar_trayectoria__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers modeloo_robot__srv__detail__ejecutar_trayectoria__rosidl_typesupport_introspection_c__EjecutarTrayectoria_service_members = {
  "modeloo_robot__srv",  // service namespace
  "EjecutarTrayectoria",  // service name
  // the following fields are initialized below on first access
  NULL,  // request message
  // modeloo_robot__srv__detail__ejecutar_trayectoria__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_message_type_support_handle,
  NULL,  // response message
  // modeloo_robot__srv__detail__ejecutar_trayectoria__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_message_type_support_handle
  NULL  // event_message
  // modeloo_robot__srv__detail__ejecutar_trayectoria__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_message_type_support_handle
};


static rosidl_service_type_support_t modeloo_robot__srv__detail__ejecutar_trayectoria__rosidl_typesupport_introspection_c__EjecutarTrayectoria_service_type_support_handle = {
  0,
  &modeloo_robot__srv__detail__ejecutar_trayectoria__rosidl_typesupport_introspection_c__EjecutarTrayectoria_service_members,
  get_service_typesupport_handle_function,
  &modeloo_robot__srv__EjecutarTrayectoria_Request__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Request_message_type_support_handle,
  &modeloo_robot__srv__EjecutarTrayectoria_Response__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Response_message_type_support_handle,
  &modeloo_robot__srv__EjecutarTrayectoria_Event__rosidl_typesupport_introspection_c__EjecutarTrayectoria_Event_message_type_support_handle,
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_CREATE_EVENT_MESSAGE_SYMBOL_NAME(
    rosidl_typesupport_c,
    modeloo_robot,
    srv,
    EjecutarTrayectoria
  ),
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_DESTROY_EVENT_MESSAGE_SYMBOL_NAME(
    rosidl_typesupport_c,
    modeloo_robot,
    srv,
    EjecutarTrayectoria
  ),
  &modeloo_robot__srv__EjecutarTrayectoria__get_type_hash,
  &modeloo_robot__srv__EjecutarTrayectoria__get_type_description,
  &modeloo_robot__srv__EjecutarTrayectoria__get_type_description_sources,
};

// Forward declaration of message type support functions for service members
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria_Request)(void);

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria_Response)(void);

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria_Event)(void);

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_modeloo_robot
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria)(void) {
  if (!modeloo_robot__srv__detail__ejecutar_trayectoria__rosidl_typesupport_introspection_c__EjecutarTrayectoria_service_type_support_handle.typesupport_identifier) {
    modeloo_robot__srv__detail__ejecutar_trayectoria__rosidl_typesupport_introspection_c__EjecutarTrayectoria_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)modeloo_robot__srv__detail__ejecutar_trayectoria__rosidl_typesupport_introspection_c__EjecutarTrayectoria_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria_Response)()->data;
  }
  if (!service_members->event_members_) {
    service_members->event_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, modeloo_robot, srv, EjecutarTrayectoria_Event)()->data;
  }

  return &modeloo_robot__srv__detail__ejecutar_trayectoria__rosidl_typesupport_introspection_c__EjecutarTrayectoria_service_type_support_handle;
}
