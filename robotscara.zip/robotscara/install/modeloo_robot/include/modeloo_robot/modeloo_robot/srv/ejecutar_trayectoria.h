// generated from rosidl_generator_c/resource/idl.h.em
// with input from modeloo_robot:srv/EjecutarTrayectoria.idl
// generated code does not contain a copyright notice

#ifndef MODELOO_ROBOT__SRV__EJECUTAR_TRAYECTORIA_H_
#define MODELOO_ROBOT__SRV__EJECUTAR_TRAYECTORIA_H_

#include "modeloo_robot/srv/detail/ejecutar_trayectoria__struct.h"
#include "modeloo_robot/srv/detail/ejecutar_trayectoria__functions.h"
#include "modeloo_robot/srv/detail/ejecutar_trayectoria__type_support.h"

#endif  // MODELOO_ROBOT__SRV__EJECUTAR_TRAYECTORIA_H_
