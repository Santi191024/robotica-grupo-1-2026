# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(modeloo_robot_IDL_FILES "srv/EjecutarTrayectoria.idl")
set(modeloo_robot_INTERFACE_FILES "srv/EjecutarTrayectoria.srv")
